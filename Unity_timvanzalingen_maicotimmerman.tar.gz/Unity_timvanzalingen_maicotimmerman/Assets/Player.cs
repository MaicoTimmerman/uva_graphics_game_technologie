/* Computer Graphics, Assignment, Unity
 * Filename ........ Player.cs
 * Description ..... The player itself
 *
 * Student name .... Maico Timmerman, Tim van Zalingen
 * Student email ... maico.timmerman@gmail.com, timvzalingen@gmail.com
 * Collegekaart .... 10542590, 10784012
 * Date ............ 18 maart 2015
 */
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Player : MonoBehaviour {

    private Rigidbody2D body;
    public GameObject projectile;
    public static int enemiesDestroyed;
    public static int lives = 3;
    public Text points;
    public Text timer;
    public Text livesText;
    public Animator anim;
    public static bool projectileFired = false;
    private float startTime;
    private float currentTime;
    private float fireDirection;
    private float xForce = 200f;
    private float xMaxSpeed = 5f;
    private float yForce = 1200f;

    // Use this for initialization
    void Start () {
        body = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        fireDirection = 1f;
        points.text = "Score: 0";
        timer.text = "Elapsed time: 00:00";
        livesText.text = "Lives: 3";
        startTime = Time.time;
        enemiesDestroyed = 0;
        lives = 3;
    }

    // Update is called once per frame
    void Update () {
        /* below the text will be set. 'points' shows the amount of enemies
         * destroyed or the score. 'timer' gets the time by using currentTime.
         * 'livesText' shows the amount of lives left. */
        points.text = System.String.Format("Score: {0}", enemiesDestroyed);
        if (!Flag.gameDone)
            currentTime = Time.time - startTime;
        timer.text = System.String.Format ("Elapsed time: {0:00}:{1:00}:{2:00}",
                currentTime/60f, currentTime%60f, (currentTime * 10) % 10);
        livesText.text = System.String.Format ("Lives: {0}", lives);
    }

    /* When a collision happens this function is called. */
    void OnCollisionEnter2D(Collision2D coll) {
        /* If the collision is with an enemy, you will lose a live.
         * Destroy the enemy, to not collide infinitely with it. */
        if (coll.gameObject.layer == LayerMask.NameToLayer("Enemy")) {
            lives -= 1;
            Destroy (coll.gameObject);
        }
        // DEAD, restart.
        if (lives < 1) Application.LoadLevel(Application.loadedLevel);
    }

    void FixedUpdate() {
        /* When the game is done, nothing happens to the player. */
        if (Flag.gameDone)
            return;

        /* The horizontal movement is the movement in the x axis. When the
         * velocity is lower than the maximum speed, our player can accelerate.
         * The animation direction and fire direction is set, after which a
         * force is set towards what x returns. x is -1 for 'a', 0 for nothing
         * pressed for the horizontal input and 1 for 'd'. */
        float x = Input.GetAxisRaw ("Horizontal");
        if (x * body.velocity.x < xMaxSpeed) {
            if (x == -1) {
                fireDirection = -1f;
                anim.CrossFade("playerLeft", 0f);
            } else if (x == 1) {
                fireDirection = 1f;
                anim.CrossFade("playerRight", 0f);
            } else if (x == 0) {
                if (fireDirection == -1f) {
                    anim.CrossFade("playerLeftIdle", 0f);
                } else {
                    anim.CrossFade("playerRightIdle", 0f);
                }
            }
            body.AddForce (transform.right * x * xForce);
        }

        if (Input.GetButtonDown ("Jump")) {
            /* Two rays are casted downwards, with maximum length of the player
             * to check if the player is standing on the ground. If he is,
             * a jump can happen. One ray is shot from the right side of the
             * player, the other one from the left side of the player.*/
            int layerMask = ~(Physics.IgnoreRaycastLayer | (1 << gameObject.layer));
            Vector2 ground = GetComponent<BoxCollider2D>().bounds.extents;
            float extentX = ground.x;
            ground.x = 0;
            Vector3 offset = new Vector3(extentX, 0f);
            RaycastHit2D flooredR = Physics2D.Raycast(
                transform.position + offset, Vector2.down, ground.magnitude * 1.1f,
                    layerMask);
            RaycastHit2D flooredL = Physics2D.Raycast(
                transform.position - offset, Vector2.down, ground.magnitude * 1.1f,
                layerMask);
            if (flooredL.collider != null || flooredR.collider != null) {
                body.AddForce (transform.up * yForce);
            }
        }

        if (Input.GetButtonDown ("Fire1") && !projectileFired) {
            /* Shoot a projectile to the side that we are last looked to,
             * only one projectile can be present in the game. */
            GameObject fired = Instantiate (projectile, transform.position + (transform.right * 0.8f * fireDirection), transform.rotation) as GameObject;
            fired.GetComponent<Rigidbody2D>().AddForce (((transform.right * fireDirection)) * 1000f);
            projectileFired = true;
        }
    }
}
