﻿/* Computer Graphics, Assignment, Unity
 * Filename ........ Hostile.cs
 * Description ..... An hostile
 *
 * Student name .... Maico Timmerman, Tim van Zalingen
 * Student email ... maico.timmerman@gmail.com, timvzalingen@gmail.com
 * Collegekaart .... 10542590, 10784012
 * Date ............ 18 maart 2016
 */
using UnityEngine;
using System.Collections;

public class Hostile : MonoBehaviour {

    /* Boolean determining left or right movement and float for speed. */
    private bool right = true;
    private float speed = 0.1f;
    public Animator anim;

    // Use this for initialization
    void Start () {
        anim = GetComponent<Animator>();
    }

    void FixedUpdate() {
        /* Do nothing if the game is done. */
		if (Flag.gameDone)
			return;

        /* In the leftern example below our (square) enemy is shooting a ray
         * to the left and right. The ray to the right with a set max length
         * is not hitting the platform, that means our enemy is almost falling
         * off the platform, thus needs to change direction. Otherwise in the
         * rightern example when both rays hit the platform, it can stay moving
         * in the current direction.
         *
         * Almost falling off: | Safely on platform:
         *       ----          |       ----
         *      |    |         |      |    |
         *      |    |         |      |    |
         *      /----\         |      /----\
         *  ----------\        | --------------------
         *             \       |
         *
         * We have chosen for this instead of placing to bounding objects on
         * the leftmost and rightmost part of the platform for a few reasons.
         * Firstly it doesn't need a lot of code. It keeps the code in the
         * hostile itself. The size or position of platform or hostile doesn't
         * matter, place a hostile and platform and this automatically works.
         */


        /* Rays only collide with self and player. */
        int layerMask = ~(Physics.IgnoreRaycastLayer | (1 << gameObject.layer) | (1 << LayerMask.NameToLayer("Player")));

        /* Extents contain the borders of our BoxCollider2D compared to the origin. */
        Vector2 extentsRight = GetComponent<BoxCollider2D>().bounds.extents * -1;
        Vector2 extentsLeft = GetComponent<BoxCollider2D>().bounds.extents * -1;
        extentsLeft.x *= -1;

        /* Shoot both rays */
        RaycastHit2D hitRight = Physics2D.Raycast(
                transform.position, extentsLeft,
                extentsLeft.magnitude * 1.1f, layerMask);
        RaycastHit2D hitLeft = Physics2D.Raycast(
                transform.position, extentsRight,
                extentsRight.magnitude * 1.1f, layerMask);

        /* No movement for no rays hit. */
        if (hitRight.collider == null && hitLeft.collider == null) {
            return;
        }

        /* Left hit is move right, right hit is move left. */
        if (hitLeft.collider == null) {
            right = true;
        } else if (hitRight.collider == null) {
            right = false;
        }

        /* The movement. */
        if (right) {
            transform.Translate (Vector2.right * speed);
            anim.CrossFade("hostileRight", 0f);
        } else {
            transform.Translate (Vector2.left * speed);
            anim.CrossFade("hostileLeft", 0f);
        }
    }

    /* On destruction the player gets a point. */
    void OnDestroy() {
		Player.enemiesDestroyed += 1;
    }

    /* When our hostile is invisible and not on a platform we can asume the
     * player knnocked it off, so it can be destroyed. */
    void OnBecameInvisible() {
        /* Masking the hostile itself. A ray is shot down to check for a
         * platform */
        int layerMask = ~(Physics.IgnoreRaycastLayer | (1 << gameObject.layer));
        Vector2 ground = GetComponent<BoxCollider2D>().bounds.extents;
        RaycastHit2D floored = Physics2D.Raycast(
                transform.position, Vector2.down, ground.magnitude * 1.1f,
                layerMask);

        if (!floored) Destroy (gameObject);
    }

    /* Action on collision. */
    void OnCollisionEnter2D(Collision2D coll) {
        /* Collision with a projectile means destruction of the hostile
         * itself. */
        if (coll.gameObject.layer == LayerMask.NameToLayer("Projectile")) {
            Destroy(gameObject);
        }
        /* Collision with another hostile (enemy) means change of direction */
		if (coll.gameObject.layer == LayerMask.NameToLayer ("Enemy")) {
			right = !right;
		}
    }
}
