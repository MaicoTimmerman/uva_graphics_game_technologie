﻿/* Computer Graphics, Assignment, Unity
 * Filename ........ Projectile.cs
 * Description ..... The projectiles fired by the player
 *
 * Student name .... Maico Timmerman, Tim van Zalingen
 * Student email ... maico.timmerman@gmail.com, timvzalingen@gmail.com
 * Collegekaart .... 10542590, 10784012
 * Date ............ 4 maart 2015
 *
 * This class is the behaviour of the projectiles that can be fired by the
 * player.
 */
using UnityEngine;
using System.Collections;

public class Projectile : MonoBehaviour {

    // Use this for initialization
    void Start () {

    }

    // Update is called once per frame
    void Update () {

    }

    /* When they have a collision, the projectiles need to be destroyed and the
     * player is allowed to fire another one, */
    void OnCollisionEnter2D(Collision2D coll) {
        Destroy (gameObject);
        Player.projectileFired = false;
    }

    /* When a projectile becomes invisible, it needs to be destroyed and the
     * player is allowed to fire another one. */
    void OnBecameInvisible() {
        Destroy (gameObject);
        Player.projectileFired = false;
    }
}
