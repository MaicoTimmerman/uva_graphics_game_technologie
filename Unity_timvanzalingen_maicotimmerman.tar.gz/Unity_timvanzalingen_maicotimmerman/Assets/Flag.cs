﻿/* Computer Graphics, Assignment, Unity
 * Filename ........ Flag.cs
 * Description ..... Flag (end of level)
 *
 * Student name .... Maico Timmerman, Tim van Zalingen
 * Student email ... maico.timmerman@gmail.com, timvzalingen@gmail.com
 * Collegekaart .... 10542590, 10784012
 * Date ............ 18 maart 2016
 *
 * The flag marks the end of the level. When it is touched by the player,
 * the level is completed.
 */
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Flag : MonoBehaviour {
    public Text winText;
    public Text winText2;
    public static bool gameDone;

    // Use this for initialization
    void Start () {
        winText.text = "";
        winText2.text = "";
        gameDone = false;
    }

    /* When the game is completed and 'Enter' or 'Return' is pressed, the level
     * needs to reload. */
    void FixedUpdate () {
        if (Input.GetButtonDown ("Fire3") && gameDone) {
            Application.LoadLevel(Application.loadedLevel);
        }
    }

    /* This function is called when something collides with the flag. When it
     * is the player, the level is completed. */
    void OnTriggerEnter2D(Collider2D coll) {
        if (coll.gameObject.layer == LayerMask.NameToLayer ("Player")) {
            winText.text = "You win!";
            winText2.text = "Press 'enter' to restart";
            gameDone = true;
        }
    }

}
