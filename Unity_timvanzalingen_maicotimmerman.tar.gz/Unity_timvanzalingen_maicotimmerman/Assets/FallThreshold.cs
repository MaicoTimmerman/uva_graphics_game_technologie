﻿/* Computer Graphics, Assignment, Unity
 * Filename ........ FallThreshold.cs
 * Description ..... Fall threshold
 *
 * Student name .... Maico Timmerman, Tim van Zalingen
 * Student email ... maico.timmerman@gmail.com, timvzalingen@gmail.com
 * Collegekaart .... 10542590, 10784012
 * Date ............ 18 maart 2016
 *
 * The fall threshold is an object below our game, when it is hit, the object
 * hitting it will be destroyed. The player will be reset and loses a life.
 */
using UnityEngine;
using System.Collections;

public class FallThreshold : MonoBehaviour {

    /* When a collision happens, the object will be destroyed. The player gets
     * reset with one life less. */
    void OnCollisionEnter2D(Collision2D coll) {
        if (coll.gameObject.layer == LayerMask.NameToLayer ("Player")) {
            coll.gameObject.transform.position = new Vector2 (0f, 1.1f);
            Player.lives -= 1;
        } else {
            Destroy (coll.gameObject);
        }
    }
}
