# Computer Graphics, Assignment, Unity
Student names ...... Maico Timmerman, Tim van Zalingen
Student emails ..... maico.timmerman@gmail.com, timvzalingen@gmail.com
Collegekaartnummers. 10542590, 10784012
Date ............... 18 maart 2016
Unity version ...... 5.1.0f3 Personal

## Exercise
Our game has the basics as described in the exercise. However some parts of the
exercise are done differently then described.

Since Unity 5 there is an easier way to do one-way platforms in a level. A
platform effector can be added to a object, in which the one-way property can be
set. Using the platform effector causes the invisible box under the platform to
be unnecessary.

The behaviour of the enemies has also been done differently then described.
Every enemy determines for itself if is has reached the corner of a platform and
will turn around. This makes the boxes at the edges of the platform unnecessary.
With this solution the platforms and the enemies can be placed without the need
for additional objects to keep the game working.

## Additions
The extra addition we have made are the animations. The animations are made
possible by controlling an Animator based on the state of the player and the
enemies.

## Controls
The game can be played using the A, W, S, D buttons. Shooting projectiles at
enemies can be done using the spacebar.
